<?php
//$deviceToken = '6b8ebbb4227f47f45906abbeff2f78c07e99f7e45bec909a515e6802f0232d0e '; // appstore production
//$deviceToken = '4ee0c660cd41e085994df71310677c8a28e22b02abd146a2964bff185ebcac6d'; // appstore production
//$deviceToken = '4ee0c660cd41e085994df71310677c8a28e22b02abd146a2964bff185ebcac6d'; // appstore production
//$deviceToken = '30e3d5ae5a5926dcd44fb74998c4228b613f465a95bc90418a2899f888bd9831'; // appstore production
//$deviceToken = '11d726206cd2e678d2a633ce392d4508fe6d82d1906e570178a07d6c9bccd014'; // appstore production
//$deviceToken = '5651d96e9dfdd4046937fe20099784dc1d94051410c75a43b16cc310fd43ef88'; // appstore production
//$deviceToken = '14ab944d2c8b1a7c16a6b5f8eb96d7eababd9f81bb336aa7493d61360e786754'; // appstore production
//$deviceToken = 'b5c519e28822ea51268556f1662a7b875c6aeda9a2e108994a7e225bfe07efcb'; // appstore production
//$deviceToken = 'affda3b44bf51f2cb9399d165fd4c455cf756e1a9f57bb0d26d2d6bb0fce445d'; // appstore production
//affda3b44bf51f2cb9399d165fd4c455cf756e1a9f57bb0d26d2d6bb0fce445d
//$deviceToken = '1d4ac2393d4f0c055250fdd909a93c1969ccef2d84f6e5504936d0fd1182f900'; // appstore production
//$deviceToken = 'aef6caddb2bb523b475e1b129c03cacd40cd798339e9062cf2ce9209ef5fe9df'; // appstore production
//$deviceToken = '251bccd298a9b856649f72a02d8d51372e7faac89a33e04d2a137ad1f903f485'; // appstore production
//$deviceToken = 'b86398fe9a1311531628705dc6be09dd4869e76d2bac057055ae7e5b2e4e11a6'; // appstore production
//$deviceToken = 'b86398fe9a1311531628705dc6be09dd4869e76d2bac057055ae7e5b2e4e11a6'; // appstore production
//$deviceToken = '0b2d87e4d48f7a24062ea3a0ec06806ef3ed7c6235286b114ee7ec3fa3dad35c';
//$deviceToken = 'ace1b5b851897d2eea2adfb8470cf160d6d40acfb52d1fcbe5462640e7bc990f';
//$deviceToken = 'a9c2a85bc70deb836e51c0a82ed093f3201a354e9b714e0c9679e848cdc0fbf5';
// $deviceToken = 'b829a61ddfa344e06099a341a9e14c0a8c461efbd7e55f9908f26e1b4b727602';
// $deviceToken='9e031b3b68bb1db88baac7a22852049f1aa63de821206c0dd08081741039333';
//$deviceToken = '81cd1e42d157cf2cf36d76b843a799daad514302df840f8bf609d40e6c299576';
//$deviceToken = '16b9d289aaf78845d07dd6e9d51b625ee4c7856035ba6045078ed6c449d85778';
//$deviceToken='ace1b5b851897d2eea2adfb8470cf160d6d40acfb52d1fcbe5462640e7bc990f';
// $deviceToken='12d0ebdc53b8098470f91039459dc7f5150b6d15fd64d13fb3316411e1f4f';
// $deviceToken='251bccd298a9b856649f72a02d8d51372e7faac89a33e04d2a137ad1f903f485';
// $deviceToken='8b6caaf815d27e4da2d7fb7ea19d00a4ea1280df65e4e95d4baa7925cb19a7c0';
// $deviceToken='e88854f930bd1861376d09c7570d21d54b0fc1435260ca6c9930f94ebd7f8bb1';
// $deviceToken='dfb6998214b89e675c2e4a96e161c3cd3b79c453ba2ba4ed3f0c810fb413ae5e';
// $deviceToken='fb08297331f3f4ff48857350f20e33bf9e74c19a8892651477d70c9402245226';	//贤明的iPod5 iOS7
// $deviceToken='64e9c75317bd41bf11ab45d5f7b66b6e585fd6b9e3a4e02d8a0cfd80eb89a0aa';	//iOS8
// $deviceToken='fe019b6f8f636b0f27671862be745d319f6b57e2ee8aedaf68d255cbd55c97a2';	//红色的iPod4 iOS6
// $deviceToken='57b61b21eddb89dba55536514c02ae6a2d393cac7f7c9912da7ba11930e29f62';	//黄色的iPhone5C iOS7
// $deviceToken='64e9c75317bd41bf11ab45d5f7b66b6e585fd6b9e3a4e02d8a0cfd80eb89a0aa';	//红色的iPod5 iOS8
// $deviceToken='baff65f82d60782dc051fbe7fd267fad6b0aa15db033166256b664abc3a998db';	//白色的iPod4 iOS5
// $deviceToken='315ee3aa66b234452f06a8435500b4e1b09924c5e6d495a0f0d3f14abab296c3';	//白色的iPhone4 iOS7
// $deviceToken='3720a865133683982686c517676ff4cbe73203a63370557bdbe8305d6cbaffbc';
$deviceToken='187f7d01a3e32e8b33941869bbad7e9f65c59036b6cf935000058333e4181222'; //我的ip6+ dev
$deviceToken='ce01bcfbc151b66706449d5cfc42b3464e044f89162bf88076b8bff55099cf27'; //小潘的ip6 dev
$deviceToken='3bfd02277433d60afd8f5f8cc7058eda93930bc2ba6c88c079275b0af1be976b';
$deviceToken='a88704c8eab8d012ca16bfcf6c111de88999d8f453bfdebef20a6045e9694297';
// Passphrase for the private key (ck.pem file)
// $pass = '';
// Get the parameters from http get or from command line
$message = $_GET['message'] or $message = $argv[1] or $message = 'Message received from zxx';
$badge = (int)$_GET['badge'] or $badge = (int)$argv[2];
$sound = $_GET['sound'] or $sound = $argv[3];
// Construct the notification payload
$data = array();
$data['url'] = 'http://121.14.161.118:8202/ldus_st';
$data['type'] = 'us';
$data['items'] = ['..\..\..\..\Documents\Profile\realTimeData.plist'];//['nlp_navi_dzh'];
// $data['openWith'] = 1;

$body = array();
$body['aps'] = array('alert' => $message);
$body['aps']['badge'] = 0;
// $body['aps']['content-available'] = 1;	
if ($sound)
$body['aps']['sound'] = $sound;
//{"aps":{"alert":"This is some fancy message.","badge":1},"URL":"www.sina.com.cn"}
$body['msgId'] = 'yytest123';
$body['cmd'] = 'fet';
$body['bus'] = 'novel';
// $body['der'] = 1;
$body['data'] = $data;
$body['url'] = 'itms-services://?action=download-manifest&url=https://uctest.ucweb.com/otaCreater52/cipackages/4904cc47f6fb94cd0a74d2debc2a3467/UCWEB.plist'; //'http://pfdev.uodoo.com/liutao/ldus_test';
$body['openWith'] = 1;


/* End of Configurable Items */
$ctx = stream_context_create();
stream_context_set_option($ctx, 'ssl', 'local_cert', 'ck_dev.pem');
// assume the private key passphase was removed.
// stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
//$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);
//distribustion environment
// $apnsUrl = 'ssl://gateway.push.apple.com:2195';
//development environment
$apnsUrl = 'ssl://gateway.sandbox.push.apple.com:2195';
print "Connecting to $apnsUrl\n";
$fp = stream_socket_client($apnsUrl, $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);
if (!$fp) {
print "Failed to connect $err $errstr\n";
return;
}
else {
print "Connection OK\n";
}
print "token $deviceToken\n";
$payload = json_encode($body);
$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
print "sending message :" . $payload . "\n";
// print "payload's length :" . strlen($payload) . "\n";
$ret = fwrite($fp, $msg);
print "$ret bytes written\n";
fclose($fp);
?>
