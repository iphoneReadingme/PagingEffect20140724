# php -f apns.php "十一区哪儿玩？全国5A景区门票均价已达108元，百元以上超半数，免费景区只有15家；175个5A景区门票排行榜，出行必备！" 2 "default"
# 执行本sh,向设备push消息
php -f apns.php "YY's 【2015-03-23】消息中心测试 notifications" 2 "default"